Measuring Action Reversibility in a Tool-Using Language Model

Select report.tex as the main file in Overleaf or run latexmk -pdf report.tex.
ACL style revision: d5adc823ff0f80f98c80405ca0ab66c68e684409
https://github.com/acl-org/acl-style-files/tree/d5adc823ff0f80f98c80405ca0ab66c68e684409
